public class Words
{
   /**
      Gets a string consisting of all vowels contained in a given string. Vowels are
      A E I O U a e i o u
      @param s a string
      @return a string with all vowels in s, in the order in which they appear in s
   */
   public String getVowels(String s)
   {
      String return_str = "";
      
      // your work here
      for (int i = 0; i < s.length(); i++) {
         switch (s.charAt(i)) {
            case 'a': case 'e': case 'i': case 'o': case 'u':
            case 'A': case 'E': case 'I': case 'O': case 'U':
               return_str += s.charAt(i);
         }
      }
      
      return return_str;
   }
}