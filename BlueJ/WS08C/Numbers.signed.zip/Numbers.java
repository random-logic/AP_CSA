public class Numbers
{
   /**
      Counts the number of perfect squares in a given range
      @param a the lower bound of the range
      @param b the upper bound of the range
      @return the number of perfect squares in the range [a,b] (including the bounds)
   */
   public int countPerfectSquares(int a, int b)
   {
      int perfect_squares = 0;
      
      int i = 0;
      
      for (; i * i < a; i++);
      
      for (; i * i <= b; i++)
         perfect_squares++;
      
      return perfect_squares;
   }
}