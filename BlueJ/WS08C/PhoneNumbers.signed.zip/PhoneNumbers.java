public class PhoneNumbers
{
   /**
      Cleans a phone number.
      @param phoneNumber a phone number that should contain ten digits and possibly other characters
      @return the phone number in the form (###) ###-#### or the string "Error" if phoneNumber
      does not have ten digits
   */
   public String cleanNumber(String phoneNumber)
   {   
      String return_string = "(";
      
      // your work here
      for (int i = 0; i < phoneNumber.length(); i++)
      {
         char ch = phoneNumber.charAt(i);
         if (Character.isDigit(ch))
            return_string += ch;
         
         if (return_string.length() == 4)
            return_string += ") ";
         else if (return_string.length() == 9)
            return_string += "-";
      }
      
      if (return_string.length() != 14)
         return "Error";
      
      return return_string;
   }   
}