/**
   A class to compare numbers.
*/
public class Numbers
{
   /**
      Checks whether three numbers have all the same sign.
      @return true if all of the numbers a, b, and c have the same sign
   */
   public boolean allSameSign(int a, int b, int c)
   {
      // your work here
      if (a < 0 && b < 0 && c < 0)
         return true;
      if (a > 0 && b > 0 && c > 0)
         return true;
      if (a == 0 && b == 0 && c == 0)
         return true;
      return false;
   }
}