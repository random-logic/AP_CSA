/**
   A class to compare numbers.
*/
public class Numbers
{
   /**
      Checks whether four numbers are all the same
      @return true if all of the numbers a, b, c, d are equal to another
   */
   public boolean allTheSame(int a, int b, int c, int d)
   {
      // your work here
      if (a == b && b == c && c == d)
         return true;
      return false;
   }
}