import java.awt.Container;
import java.awt.GridLayout;
import javax.swing.JFrame;

/**
 * Model-View-Controller example:
 * the MVC sphere demo.
 */
public class MVCSphereDemo extends JFrame
{
  public MVCSphereDemo()
  {
    super("MVC Demo");

    Sphere model = new Sphere(0, 0, 50);

    TextController tController = new TextController(model);
    GraphicsController gController = new GraphicsController(model);

    TextView tView = new TextView();
    tView.addActionListener(tController);
    tView.update(model, null);
    GraphicsView gView = new GraphicsView();
    gView.addMouseListener(gController);
    gView.addMouseMotionListener(gController);
    gController.setMousePanel(gView);

    gView.update(model, null);
    model.addObserver(tView);
    model.addObserver(gView);
    model.notifyObservers();

    Container c = getContentPane();
    c.setLayout(new GridLayout(1, 2));
    c.add(tView);
    c.add(gView);
  }

  public static void main(String[] args)
  {
    MVCSphereDemo window = new MVCSphereDemo();
    window.setBounds(100, 100, 500, 250);
    window.setDefaultCloseOperation(EXIT_ON_CLOSE);
    window.setResizable(false);
    window.setVisible(true);
  }
}
